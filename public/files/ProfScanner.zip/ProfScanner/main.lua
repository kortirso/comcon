﻿ProfScanner = LibStub("AceAddon-3.0"):NewAddon("ProfScanner", "AceConsole-3.0")

function ProfScanner:OnInitialize()
  ProfScanner:RegisterChatCommand("ps", "SlashCommands")
end

local professions = {
  {spell = "Кулинария", func = function() ProfScanner.ScanCooking() end},
  {spell = "Наложение чар", func = function() ProfScanner.ScanEnchanting() end},
  {spell = "Алхимия", func = function() ProfScanner.ScanAlchemy() end},
  {spell = "Кожевничество", func = function() ProfScanner.ScanLeatherworking() end},
  {spell = "Инженерное дело", func = function() ProfScanner.ScanEngineering() end},
  {spell = "Портняжное дело", func = function() ProfScanner.ScanTailoring() end},
  {spell = "Кузнечное дело", func = function() ProfScanner.ScanBlacksmithing() end},
  {spell = "Выплавка металлов", func = function() ProfScanner.ScanMining() end}
}

local equipmentSlots = {
	"HEADSLOT", 
	"NECKSLOT", 
	"SHOULDERSLOT", 
	"SHIRTSLOT", 
	"CHESTSLOT", 
	"WAISTSLOT", 
	"LEGSSLOT", 
	"FEETSLOT", 
	"WRISTSLOT", 
	"HANDSSLOT", 
	"FINGER0SLOT", 
	"FINGER1SLOT", 
	"TRINKET0SLOT", 
	"TRINKET1SLOT", 
	"BACKSLOT", 
	"MAINHANDSLOT", 
	"SECONDARYHANDSLOT", 
	"RANGEDSLOT", 
	"TABARDSLOT"
}

function ProfScanner:SlashCommands(args)
  local arg = self:GetArgs(args, 2)
  if arg == "Cooking" then
    CastSpellByName(professions[1].spell)
    C_Timer.After(1, professions[1].func)
  elseif arg == "Enchanting" then
    CastSpellByName(professions[2].spell)
    C_Timer.After(1, professions[2].func)
  elseif arg == "Alchemy" then
    CastSpellByName(professions[3].spell)
    C_Timer.After(1, professions[3].func)
  elseif arg == "Leatherworking" then
    CastSpellByName(professions[4].spell)
    C_Timer.After(1, professions[4].func)
  elseif arg == "Engineering" then
    CastSpellByName(professions[5].spell)
    C_Timer.After(1, professions[5].func)
  elseif arg == "Tailoring" then
    CastSpellByName(professions[6].spell)
    C_Timer.After(1, professions[6].func)
  elseif arg == "Blacksmithing" then
    CastSpellByName(professions[7].spell)
    C_Timer.After(1, professions[7].func)
  elseif arg == "Mining" then
    CastSpellByName(professions[8].spell)
    C_Timer.After(1, professions[8].func)
  elseif (arg or ''):lower() == "items" then
    ProfScanner.ScanEquipment()
  end
end

function ProfScanner:ScanMining() 
  local exportString = GetLocale() .. ';' .. professions[8].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end
  
  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanBlacksmithing() 
  local exportString = GetLocale() .. ';' .. professions[7].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end
  
  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanTailoring() 
  local exportString = GetLocale() .. ';' .. professions[6].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end
  
  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanEngineering() 
  local exportString = GetLocale() .. ';' .. professions[5].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end
  
  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanLeatherworking() 
  local exportString = GetLocale() .. ';' .. professions[4].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end
  
  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanCooking() 
  local exportString = GetLocale() .. ';' .. professions[1].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end
  
  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanEnchanting() 
  local exportString = GetLocale() .. ';' .. professions[2].spell .. ';'
  local craftsN = GetNumCrafts()

  for i = 1, craftsN do
    local craftName, _, skillType = GetCraftInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end

  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanAlchemy() 
  local exportString = GetLocale() .. ';' .. professions[3].spell .. ';'
  local craftsN = GetNumTradeSkills()

  for i = 1, craftsN do
    local craftName, skillType = GetTradeSkillInfo(i)
    if craftName and skillType ~= "header" then
      exportString = exportString .. craftName .. ';'
    end
  end

  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end

function ProfScanner:ScanEquipment() 
  local exportString = ''
  
  for i = 1, #equipmentSlots do
	local itemId = 0
	local enchantId = 0
  
	local slotID = GetInventorySlotInfo(equipmentSlots[i])
	local itemId = GetInventoryItemID("player", slotID) or 0
	if itemId > 0 then
		local itemLink = GetInventoryItemLink("player", slotID)
		--print(equipmentSlots[i]..'-'..itemLink)
		local itemString = string.match(itemLink, "item[%-?%d:]+")
		--print(itemString)
		if itemString ~= nil then
			local id, eId = string.match(itemString, "item:?(%d+):?(%d*):?(%d*):?(%d*)")
			enchantId = eId
		end
	end
	
	exportString = exportString..itemId..':'..(enchantId or 0)..';'
  end

  PsFrame:Show()
  PsFrameScroll:Show()
  PsFrameScrollText:Show()
  PsFrameScrollText:SetText(exportString)
  PsFrameScrollText:HighlightText()
  
  PsFrameButton:SetScript("OnClick", function(self)
    PsFrame:Hide();
    end
  )
end



