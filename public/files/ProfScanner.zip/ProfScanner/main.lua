ProfScanner = LibStub("AceAddon-3.0"):NewAddon("ProfScanner", "AceConsole-3.0")

function ProfScanner:OnInitialize()				
    ProfScanner:RegisterChatCommand("ps", "SlashCommands")
end

local professions = {
	{spell = "Кулинария", func = function() ProfScanner.ScanCooking() end},
	{spell = "Наложение чар", func = function() ProfScanner.ScanEnchanting() end},
	{spell = "Алхимия", func = function() ProfScanner.ScanAlchemy() end}
}

function ProfScanner:SlashCommands(args)
	local arg = self:GetArgs(args, 2)
--	self.Print(arg)
	if arg == "Cooking" then
		CastSpellByName(professions[1].spell)
		C_Timer.After(1, professions[1].func)
	elseif arg == "Enchanting" then
		CastSpellByName(professions[2].spell)
		C_Timer.After(1, professions[2].func)
	elseif arg == "Alchemy" then
		CastSpellByName(professions[3].spell)
		C_Timer.After(1, professions[3].func)
	end
end

function ProfScanner:ScanCooking() 
	local exportString = GetLocale() .. ';' .. professions[1].spell .. ';'
	local craftsN = GetNumTradeSkills()

	for i = 1, craftsN do
		local craftName, skillType = GetTradeSkillInfo(i)
		if craftName and skillType ~= "header" then
			exportString = exportString .. craftName .. ';'
		end
	end
	
	PsFrame:Show()
	PsFrameScroll:Show()
	PsFrameScrollText:Show()
	PsFrameScrollText:SetText(exportString)
	PsFrameScrollText:HighlightText()
  
	PsFrameButton:SetScript("OnClick", function(self)
		PsFrame:Hide();
		end
	)
end

function ProfScanner:ScanEnchanting() 
	local exportString = GetLocale() .. ';' .. professions[2].spell .. ';'
	local craftsN = GetNumCrafts()

	for i = 1, craftsN do
		local craftName, _, skillType = GetCraftInfo(i)
		if craftName and skillType ~= "header" then
			exportString = exportString .. craftName .. ';'
		end
	end

	PsFrame:Show()
	PsFrameScroll:Show()
	PsFrameScrollText:Show()
	PsFrameScrollText:SetText(exportString)
	PsFrameScrollText:HighlightText()
  
	PsFrameButton:SetScript("OnClick", function(self)
		PsFrame:Hide();
		end
	)
end

function ProfScanner:ScanAlchemy() 
	local exportString = GetLocale() .. ';' .. professions[3].spell .. ';'
	local craftsN = GetNumTradeSkills()

	for i = 1, craftsN do
		local craftName, skillType = GetTradeSkillInfo(i)
		if craftName and skillType ~= "header" then
			exportString = exportString .. craftName .. ';'
		end
	end

	PsFrame:Show()
	PsFrameScroll:Show()
	PsFrameScrollText:Show()
	PsFrameScrollText:SetText(exportString)
	PsFrameScrollText:HighlightText()
  
	PsFrameButton:SetScript("OnClick", function(self)
		PsFrame:Hide();
		end
	)
end



